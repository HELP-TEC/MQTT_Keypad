The demo examples for ESP32-POE-ISO and ESP32-POE are the same. Visit the SOFTWARE page of ESP32-POE for examples. Here:

https://github.com/OLIMEX/ESP32-POE/tree/master/SOFTWARE/