/*
 * adc_module.h
 *
 *  Created on: 1 avr. 2022
 *      Author: PRO
 */

#ifndef ADC_MODULE_H_
#define ADC_MODULE_H_



void potentiometer_task(void *arg);
void potentiometer_config(void);

#endif /* ADC_MODULE_H_ */
