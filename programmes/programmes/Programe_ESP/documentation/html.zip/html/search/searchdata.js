var indexSectionsWithContent =
{
  0: "abcdegilmnoprstuwx",
  1: "gt",
  2: "abm",
  3: "abcdgilmp",
  4: "acgnptuwx",
  5: "g",
  6: "bcdegilmoprsu"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Macros"
};

