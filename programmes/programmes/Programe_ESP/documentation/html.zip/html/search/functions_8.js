var searchData=
[
  ['potentiometer_5fconfig',['potentiometer_config',['../adc__module_8c.html#a7d8285bb0f1559611bcb27a008a24175',1,'potentiometer_config():&#160;adc_module.c'],['../adc__module_8h.html#aa0293b8ca2f9be7cf2374fb054350bf6',1,'potentiometer_config(void):&#160;adc_module.c']]],
  ['potentiometer_5ftask',['potentiometer_task',['../adc__module_8c.html#a7ae378077f8a0a1126f38b5d2dc86658',1,'potentiometer_task(void *arg):&#160;adc_module.c'],['../adc__module_8h.html#a7ae378077f8a0a1126f38b5d2dc86658',1,'potentiometer_task(void *arg):&#160;adc_module.c']]]
];
