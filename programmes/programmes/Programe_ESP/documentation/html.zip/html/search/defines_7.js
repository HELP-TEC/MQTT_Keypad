var searchData=
[
  ['mean_5fno_5fof_5fsamples',['MEAN_NO_OF_SAMPLES',['../adc__module_8c.html#a5c2a84074ff3d432ed3e114b772177f4',1,'adc_module.c']]],
  ['mean_5ftime_5finterval',['MEAN_TIME_INTERVAL',['../adc__module_8c.html#a8fb74a2de94b5bd9c404e22753019aed',1,'adc_module.c']]],
  ['mqtt_5ftask_5fprio',['MQTT_TASK_PRIO',['../app__main_8c.html#acc0f1173d9757324d2ec4dd2eb62debd',1,'app_main.c']]]
];
